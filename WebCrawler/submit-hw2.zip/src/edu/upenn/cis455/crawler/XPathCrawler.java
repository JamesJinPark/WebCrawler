package edu.upenn.cis455.crawler;

public class XPathCrawler {
	
  public static void main(String args[])
  {
    /* TODO: Implement crawler */
  }
	
}
